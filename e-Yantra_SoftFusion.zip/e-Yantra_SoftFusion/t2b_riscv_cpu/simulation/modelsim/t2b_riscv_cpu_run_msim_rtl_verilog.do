transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/data_mem.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/riscv_cpu.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/t2b_riscv_cpu.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/adder.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/alu.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/alu_decoder.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/controller.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/datapath.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/main_decoder.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/mux2.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/mux4.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/reg_file.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/reset_ff.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/sgn_zero_extend.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/verilog_codes/sign_extend.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules/mem_div.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules/sub_mem.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules/SIPO.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/softfusion_modules/dijkstra.v}
vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/instr_mem.v}

vlog -vlog01compat -work work +incdir+/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/simulation/modelsim {/home/dark-horse/Documents/e-Yantra_SoftFusion/t2b_riscv_cpu/simulation/modelsim/tb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneiv_hssi_ver -L cycloneiv_pcie_hip_ver -L cycloneiv_ver -L rtl_work -L work -voptargs="+acc"  tb

add wave *
view structure
view signals
run 5 ms
